module mypackage {
}